//
//  Mono.h
//  Mono
//
//  Created by xiang.liu03 on 2024/5/23.
//

#import <Foundation/Foundation.h>

//! Project version number for Mono.
FOUNDATION_EXPORT double MonoVersionNumber;

//! Project version string for Mono.
FOUNDATION_EXPORT const unsigned char MonoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Mono/PublicHeader.h>


