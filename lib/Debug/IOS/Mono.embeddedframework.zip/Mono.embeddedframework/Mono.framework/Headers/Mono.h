//
//  Mono.h
//  Mono
//
//  Created by zhustudio on 2026/1/9.
//

#import <Foundation/Foundation.h>

//! Project version number for Mono.
FOUNDATION_EXPORT double MonoVersionNumber;

//! Project version string for Mono.
FOUNDATION_EXPORT const unsigned char MonoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Mono/PublicHeader.h>
